package com.example.demo.rest;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.PersonaDao;

import com.example.demo.model.Persona;

@RestController
@RequestMapping("personas")
public class PersonaRest {
	
	@Autowired
	private PersonaDao personaDao;
	
	
	//METODOS HTTP - SOLICITUD AL SERVIDOR
	// GET, POST , PUT , DELETE  --> 200 (SE HA REALIZADO CORRECTAMENTE)
	// GET, POST , PUT , DELETE ---> 500 (ERROR DE LOGICA) , 404 (ESCRITO MAL ALGO)

	@PostMapping("/guardar")
	 public void guardar(@RequestBody Persona persona) {
		 personaDao.save(persona);
	 }
	@GetMapping("/listar")
	public List<Persona>listado(){
		
		return personaDao.findAll();
	}
	
	@PutMapping("/actualizar")
	public void actualizar(@RequestBody Persona persona) {
		personaDao.save(persona);
	}
	@DeleteMapping("/eliminar/{id}")
	public String delete(@PathVariable("id") Integer id , Persona persona) {
		
		 this.personaDao.delete(persona);
		         
				return "Se elimino Correctamente";
	}

}
